<?php 
namespace svay\Exception;

use Exception;

class NoFaceException extends Exception {

}
