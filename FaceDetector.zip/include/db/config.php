<?php
define("DATABASE_HOST", "localhost");
define("DATABASE_USERNAME", "root");
define("DATABASE_PASSWORD", ""); //databse password
define("DATABASE_NAME", "data"); //databasbe name